import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";

export default function MealPrepApp() {
  const [weight, setWeight] = useState('');
  const [energy, setEnergy] = useState(5);
  const [goals, setGoals] = useState([
    { text: "Protéines atteintes", done: false },
    { text: "Moins de sucre", done: false },
    { text: "10 000 pas", done: false },
    { text: "2L d'eau", done: false },
    { text: "Séance de sport", done: false }
  ]);

  const toggleGoal = (index) => {
    const newGoals = [...goals];
    newGoals[index].done = !newGoals[index].done;
    setGoals(newGoals);
  };

  return (
    <div className="p-6 grid gap-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-center">Mon Suivi Santé</h1>

      <Card>
        <CardContent className="p-4 grid gap-3">
          <h2 className="text-xl font-semibold">Progression du jour</h2>
          {goals.map((goal, i) => (
            <Button
              key={i}
              variant={goal.done ? "default" : "outline"}
              onClick={() => toggleGoal(i)}
              className="justify-start"
            >
              {goal.done ? "✅" : "⬜️"} {goal.text}
            </Button>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 grid gap-4">
          <h2 className="text-xl font-semibold">Mesures quotidiennes</h2>
          <div>
            <label className="block text-sm mb-1">Poids (kg)</label>
            <Input value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="ex : 68.5" />
          </div>
          <div>
            <label className="block text-sm mb-1">Énergie (1 à 10)</label>
            <Progress value={energy * 10} className="h-2" />
            <input type="range" min="1" max="10" value={energy} onChange={(e) => setEnergy(e.target.value)} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Citation du jour</h2>
          <blockquote className="italic text-center">“La discipline est le pont entre les objectifs et les résultats.”</blockquote>
        </CardContent>
      </Card>
    </div>
  );
}